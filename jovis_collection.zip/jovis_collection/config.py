STRIPE_SECRET_KEY = "sk_test_replace_with_yours"
STRIPE_PUBLISHABLE_KEY = "pk_test_replace_with_yours"
DISCOUNT_CODE = "JOVIS10"  # 10% off
